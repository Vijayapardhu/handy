import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { LoginPage } from "@/pages/Login/LoginPage";
import { HomePage } from "@/pages/Home/HomePage";
import { OverallAttendancePage } from "@/pages/OverallAttendance/OverallAttendancePage";
import { SubjectDetailPage } from "@/pages/SubjectDetail/SubjectDetailPage";
import { TimetablePage } from "@/pages/Timetable/TimetablePage";
import { LeavesPage } from "@/pages/Leaves/LeavesPage";
import { LeavePlannerPage } from "@/pages/LeavePlanner/LeavePlannerPage";
import { LeaveRequestPage } from "@/pages/LeaveRequest/LeaveRequestPage";
import { AttendancePlannerPage } from "@/pages/AttendancePlanner/AttendancePlannerPage";
import { AttendanceHistoryPage } from "@/pages/AttendanceHistory/AttendanceHistoryPage";
import { ProfilePage } from "@/pages/Profile/ProfilePage";
import { PersonalInfoPage } from "@/pages/Profile/PersonalInfoPage";
import { AcademicInfoPage } from "@/pages/Profile/AcademicInfoPage";
import { NotificationsPage } from "@/pages/Notifications/NotificationsPage";
import { NotFoundPage } from "@/pages/NotFound/NotFoundPage";
import { ROUTES } from "@/constants/routes";

const router = createBrowserRouter([
  { path: ROUTES.login, element: <LoginPage /> },
  {
    element: <ProtectedRoute />,
    children: [
      {
        element: <AppShell />,
        children: [
          { path: ROUTES.home, element: <HomePage /> },
          { path: ROUTES.subjects, element: <OverallAttendancePage /> },
          { path: ROUTES.subjectDetail(), element: <SubjectDetailPage /> },
          { path: ROUTES.subjectPlanner(), element: <AttendancePlannerPage /> },
          { path: ROUTES.timetable, element: <TimetablePage /> },
          { path: ROUTES.leaves, element: <LeavesPage /> },
          { path: ROUTES.leavePlanner, element: <LeavePlannerPage /> },
          { path: ROUTES.leaveRequestNew, element: <LeaveRequestPage /> },
          { path: ROUTES.attendancePlanner, element: <AttendancePlannerPage /> },
          { path: ROUTES.attendanceHistory, element: <AttendanceHistoryPage /> },
          { path: ROUTES.profile, element: <ProfilePage /> },
          { path: ROUTES.profilePersonal, element: <PersonalInfoPage /> },
          { path: ROUTES.profileAcademic, element: <AcademicInfoPage /> },
          { path: ROUTES.notifications, element: <NotificationsPage /> },
          { path: "*", element: <NotFoundPage /> },
        ],
      },
    ],
  },
]);

export function AppRouter() {
  return <RouterProvider router={router} />;
}
