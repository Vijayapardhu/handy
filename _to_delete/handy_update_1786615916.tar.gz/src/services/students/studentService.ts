import { getDoc, updateDoc } from "firebase/firestore";
import { studentDocRef } from "@/services/firebase/collections";
import type { StudentDoc } from "@/types/student";

/** Student doc id === Firebase Auth uid (see services/firebase/auth.ts for the login flow). */
export async function getStudentProfile(uid: string): Promise<StudentDoc | null> {
  const snapshot = await getDoc(studentDocRef(uid));
  return snapshot.exists() ? snapshot.data() : null;
}

/** Students may only edit the limited personal fields SRS §27 calls out — never roll number, course, or year. */
export type EditablePersonalFields = Pick<StudentDoc, "photoUrl">;

export async function updatePersonalInfo(
  uid: string,
  fields: Partial<EditablePersonalFields>,
): Promise<void> {
  await updateDoc(studentDocRef(uid), { ...fields, updatedAt: new Date().toISOString() });
}
