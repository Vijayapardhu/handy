import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updatePassword,
  type User,
} from "firebase/auth";
import { auth, AUTH_EMAIL_DOMAIN } from "@/app/config/firebase";

/**
 * Roll-number login (SRS request: "students login with their roll number and
 * password"). Firebase Authentication has no native roll-number method, so a
 * roll number maps deterministically to a synthetic email address and the
 * normal, well-tested email/password flow handles the rest — no custom
 * backend or Cloud Function is needed for this V1 (see README "Auth model").
 *
 * Accounts are provisioned ahead of time by an administrator (currently via
 * scripts/seed-students.mjs, which uses the Admin SDK and a service-account
 * key that never ships to the browser) — students only ever sign in here,
 * they do not self-register.
 */
export function rollNumberToEmail(rollNumber: string): string {
  const normalized = rollNumber.trim().toLowerCase();
  return `${normalized}@${AUTH_EMAIL_DOMAIN}`;
}

export async function signInWithRollNumber(rollNumber: string, password: string): Promise<User> {
  const email = rollNumberToEmail(rollNumber);
  const credential = await signInWithEmailAndPassword(auth, email, password);
  return credential.user;
}

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

export function subscribeToAuthState(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

export async function changePassword(newPassword: string): Promise<void> {
  const user = auth.currentUser;
  if (!user) throw new Error("No authenticated user.");
  await updatePassword(user, newPassword);
}

export function getCurrentUser(): User | null {
  return auth.currentUser;
}
