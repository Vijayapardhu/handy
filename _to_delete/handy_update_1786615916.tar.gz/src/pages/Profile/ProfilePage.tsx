import { Link, useNavigate } from "react-router-dom";
import {
  User,
  GraduationCap,
  Bell,
  HelpCircle,
  MessageSquare,
  Info,
  LogOut,
  ChevronRight,
} from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Skeleton } from "@/components/ui/Skeleton";
import { useAuth } from "@/app/providers/AuthProvider";
import { useSubjectsWithAttendance } from "@/hooks/useSubjects";
import { useLeaveRequests } from "@/hooks/useLeaves";
import { aggregateAttendance } from "@/lib/calculations/attendance";
import { ROUTES } from "@/constants/routes";
import styles from "./ProfilePage.module.css";

export function ProfilePage() {
  const { student, signOut } = useAuth();
  const navigate = useNavigate();
  const subjectsQuery = useSubjectsWithAttendance();
  const leavesQuery = useLeaveRequests();

  const overall = subjectsQuery.data
    ? aggregateAttendance(subjectsQuery.data.map((s) => ({ attended: s.attended, held: s.held })))
    : null;

  async function handleLogout() {
    await signOut();
    navigate(ROUTES.login, { replace: true });
  }

  if (!student) {
    return (
      <div>
        <div className={styles.header}>
          <h1 className={styles.title}>Profile</h1>
          <p className={styles.subtitle}>Manage your account and preferences</p>
        </div>
        <div className={styles.loadingStack}>
          <Skeleton height={92} />
          <Skeleton height={64} />
          <Skeleton height={160} />
          <Skeleton height={120} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className={styles.header}>
        <h1 className={styles.title}>Profile</h1>
        <p className={styles.subtitle}>Manage your account and preferences</p>
      </div>

      <Card className={styles.identityCard}>
        <div className={styles.avatar}>
          {student.name
            .split(" ")
            .map((p) => p[0])
            .slice(0, 2)
            .join("")}
        </div>
        <div className={styles.identityBody}>
          <p className={styles.name}>{student.name}</p>
          <p className={styles.meta}>
            {student.course} · Year {student.year}
          </p>
          <p className={styles.college}>{student.department}</p>
          <span className={styles.rollChip}>Roll No: {student.rollNumber}</span>
        </div>
      </Card>

      <div className={styles.statsRow}>
        <div className={styles.stat}>
          <p className={styles.statValue}>
            {overall?.percentage === null || overall?.percentage === undefined
              ? "N/A"
              : `${overall.percentage.toFixed(2)}%`}
          </p>
          <p className={styles.statLabel}>Overall Attendance</p>
        </div>
        <div className={styles.stat}>
          <p className={styles.statValue}>
            {overall?.attended ?? "–"} / {overall?.held ?? "–"}
          </p>
          <p className={styles.statLabel}>Classes Attended</p>
        </div>
        <div className={styles.stat}>
          <p className={styles.statValue}>{leavesQuery.data?.length ?? "–"}</p>
          <p className={styles.statLabel}>Leaves Taken</p>
        </div>
      </div>

      <p className={styles.sectionTitle}>Account</p>
      <Card padded={false} className={styles.linkGroup}>
        <ProfileLink to={ROUTES.profilePersonal} icon={User} title="Personal Information" subtitle="View and edit your details" />
        <ProfileLink to={ROUTES.profileAcademic} icon={GraduationCap} title="Academic Information" subtitle="Course, Year, Department" />
        <ProfileLink to={ROUTES.notifications} icon={Bell} title="Notifications" subtitle="Manage notification preferences" />
      </Card>

      <p className={styles.sectionTitle}>Support & More</p>
      <Card padded={false} className={styles.linkGroup}>
        <ProfileLink to="#" icon={HelpCircle} title="Help & FAQ" subtitle="Get help and find answers" />
        <ProfileLink to="#" icon={MessageSquare} title="Feedback" subtitle="Share your feedback with us" />
        <ProfileLink to="#" icon={Info} title="About Handy" subtitle="Version 0.1.0" />
      </Card>

      <Button variant="danger" fullWidth onClick={handleLogout} className={styles.logout}>
        <LogOut size={16} /> Log Out
      </Button>
    </div>
  );
}

function ProfileLink({
  to,
  icon: Icon,
  title,
  subtitle,
}: {
  to: string;
  icon: typeof User;
  title: string;
  subtitle: string;
}) {
  return (
    <Link to={to} className={styles.link}>
      <span className={styles.linkIcon}>
        <Icon size={18} />
      </span>
      <span className={styles.linkBody}>
        <span className={styles.linkTitle}>{title}</span>
        <span className={styles.linkSubtitle}>{subtitle}</span>
      </span>
      <ChevronRight size={16} className={styles.chevron} />
    </Link>
  );
}
