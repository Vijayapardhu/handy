import { useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Eye, EyeOff, LogIn } from "lucide-react";
import { useAuth } from "@/app/providers/AuthProvider";
import { loginSchema, type LoginFormValues } from "@/lib/validators/auth";
import { toFriendlyAuthMessage } from "@/lib/utils/errors";
import { Button } from "@/components/ui/Button";
import { ROUTES } from "@/constants/routes";
import styles from "./LoginPage.module.css";

export function LoginPage() {
  const { user, loading, signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({ resolver: zodResolver(loginSchema) });

  if (!loading && user) {
    const redirectTo = (location.state as { from?: string } | null)?.from ?? ROUTES.home;
    return <Navigate to={redirectTo} replace />;
  }

  async function onSubmit(values: LoginFormValues) {
    setSubmitError(null);
    try {
      await signIn(values.rollNumber, values.password);
      navigate(ROUTES.home, { replace: true });
    } catch (error) {
      setSubmitError(toFriendlyAuthMessage(error));
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.brand}>
        <div className={styles.logo}>H</div>
        <h1 className={styles.appName}>Handy</h1>
        <p className={styles.tagline}>Understand → Calculate → Decide → Act</p>
      </div>

      <form className={styles.form} onSubmit={handleSubmit(onSubmit)} noValidate>
        <h2 className={styles.formTitle}>Sign in</h2>
        <p className={styles.formSubtitle}>Use the roll number and password issued by your college.</p>

        <label className={styles.field}>
          <span className={styles.labelText}>Roll Number</span>
          <input
            className={styles.input}
            type="text"
            autoComplete="username"
            placeholder="23A31A05B1"
            autoCapitalize="characters"
            {...register("rollNumber")}
            aria-invalid={Boolean(errors.rollNumber)}
          />
          {errors.rollNumber && <span className={styles.fieldError}>{errors.rollNumber.message}</span>}
        </label>

        <label className={styles.field}>
          <span className={styles.labelText}>Password</span>
          <div className={styles.passwordWrap}>
            <input
              className={styles.input}
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              {...register("password")}
              aria-invalid={Boolean(errors.password)}
            />
            <button
              type="button"
              className={styles.togglePassword}
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
          {errors.password && <span className={styles.fieldError}>{errors.password.message}</span>}
        </label>

        {submitError && (
          <p className={styles.submitError} role="alert">
            {submitError}
          </p>
        )}

        <Button type="submit" fullWidth loading={isSubmitting}>
          <LogIn size={16} /> Sign In
        </Button>

        <p className={styles.helpText}>
          Forgotten your password? Contact your department office — accounts are provisioned by your
          college administrator.
        </p>
      </form>
    </div>
  );
}
