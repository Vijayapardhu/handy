import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { CheckCircle2, XCircle, CalendarOff, ShieldCheck, History } from "lucide-react";
import { TopHeader } from "@/components/layout/TopHeader";
import { Button } from "@/components/ui/Button";
import { Skeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { MonthCalendar } from "@/components/attendance/MonthCalendar";
import { useAttendanceHistory } from "@/hooks/useAttendanceHistory";
import { useAttendanceMonth } from "@/hooks/useAttendanceMonth";
import { useActiveSubjectsMap } from "@/hooks/useActiveSubjectsMap";
import { formatDisplayDate } from "@/lib/date";
import type { AttendanceStatus } from "@/types/attendance";
import { cn } from "@/lib/utils/cn";
import styles from "./AttendanceHistoryPage.module.css";

const STATUS_CONFIG: Record<AttendanceStatus, { label: string; icon: typeof CheckCircle2; className: string }> = {
  present: { label: "Present", icon: CheckCircle2, className: styles.present },
  absent: { label: "Absent", icon: XCircle, className: styles.absent },
  leave: { label: "Leave", icon: CalendarOff, className: styles.leave },
  excused: { label: "Excused", icon: ShieldCheck, className: styles.excused },
};

export function AttendanceHistoryPage() {
  const [params] = useSearchParams();
  const subjectId = params.get("subjectId") ?? undefined;
  const { records, isLoading, isError, hasMore, loadMore, reset } = useAttendanceHistory(subjectId);
  const subjectsMap = useActiveSubjectsMap();
  const [view, setView] = useState<"list" | "calendar">("list");
  const [calendarMonth, setCalendarMonth] = useState(() => new Date());

  const monthQuery = useAttendanceMonth(
    calendarMonth.getFullYear(),
    calendarMonth.getMonth() + 1,
    subjectId,
  );

  const subjectNameById = useMemo(() => {
    const map = new Map<string, string>();
    subjectsMap.bySubjectId.forEach((s, id) => map.set(id, s.shortName || s.name));
    return map;
  }, [subjectsMap.bySubjectId]);

  const groupedByDate = records.reduce<Record<string, typeof records>>((acc, r) => {
    (acc[r.date] ??= []).push(r);
    return acc;
  }, {});

  return (
    <div>
      <TopHeader title="Attendance History" subtitle="Every recorded class, by date" back />

      <div className={styles.viewToggle}>
        <button className={cn(styles.toggleBtn, view === "list" && styles.toggleActive)} onClick={() => setView("list")}>
          List
        </button>
        <button
          className={cn(styles.toggleBtn, view === "calendar" && styles.toggleActive)}
          onClick={() => setView("calendar")}
        >
          Calendar
        </button>
      </div>

      {view === "list" && (
        <>
          {isError && <ErrorState message="Unable to load your attendance history." onRetry={reset} />}

          {!isError && isLoading && (
            <div className={styles.loadingStack}>
              <Skeleton height={20} className={styles.dateHeadingSkeleton} />
              <Skeleton height={50} />
              <Skeleton height={50} />
              <Skeleton height={20} className={styles.dateHeadingSkeleton} />
              <Skeleton height={50} />
            </div>
          )}

          {!isError && !isLoading && records.length === 0 && (
            <EmptyState icon={History} title="No history yet" description="Attendance records will appear here once classes are recorded." />
          )}

          {!isError && !isLoading && records.length > 0 && (
            <div className={styles.dateGroups}>
              {Object.entries(groupedByDate).map(([date, dayRecords]) => (
                <div key={date} className={styles.dateGroup}>
                  <p className={styles.dateHeading}>{formatDisplayDate(date)}</p>
                  <ul className={styles.recordList}>
                    {dayRecords.map((r) => {
                      const config = STATUS_CONFIG[r.status];
                      const Icon = config.icon;
                      const subjectName = subjectNameById.get(r.subjectId) ?? "Subject";
                      return (
                        <li key={r.id} className={styles.record}>
                          <span>{subjectName}</span>
                          <span className={cn(styles.statusChip, config.className)}>
                            <Icon size={13} /> {config.label}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {!isError && hasMore && records.length > 0 && (
            <div className={styles.loadMoreRow}>
              <Button variant="secondary" size="sm" onClick={loadMore}>
                Load more
              </Button>
            </div>
          )}
        </>
      )}

      {view === "calendar" && (
        <>
          {monthQuery.isError && (
            <ErrorState message="Unable to load this month's attendance." onRetry={() => monthQuery.refetch()} />
          )}
          {!monthQuery.isError && monthQuery.isLoading && <Skeleton height={360} />}
          {!monthQuery.isError && !monthQuery.isLoading && (
            <MonthCalendar
              records={monthQuery.data ?? []}
              subjectNameById={subjectNameById}
              month={calendarMonth}
              onMonthChange={setCalendarMonth}
            />
          )}
        </>
      )}
    </div>
  );
}
