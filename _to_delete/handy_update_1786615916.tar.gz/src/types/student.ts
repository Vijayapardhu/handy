export interface StudentDoc {
  id: string;
  uid: string;
  rollNumber: string;
  name: string;
  email: string;
  department: string;
  course: string;
  year: number;
  section: string;
  semesterId: string;
  collegeId: string;
  photoUrl: string | null;
  createdAt: string;
  updatedAt: string;
}
