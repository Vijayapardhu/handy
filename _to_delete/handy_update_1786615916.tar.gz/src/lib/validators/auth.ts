import { z } from "zod";

/**
 * Roll numbers look like "23A31A05B1" — alphanumeric, no spaces. Kept
 * permissive (colleges vary) but rejects obviously malformed input client-side.
 * Real authorization always happens server-side via Firebase Auth (SRS §29, §57).
 */
export const rollNumberSchema = z
  .string()
  .trim()
  .min(4, "Roll number looks too short")
  .max(20, "Roll number looks too long")
  .regex(/^[A-Za-z0-9]+$/, "Roll number should only contain letters and numbers")
  .transform((val) => val.toUpperCase());

export const loginSchema = z.object({
  rollNumber: rollNumberSchema,
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginFormValues = z.infer<typeof loginSchema>;
