# Handy — Student Attendance & Academic Assistant

React + TypeScript + Vite frontend, Firebase (Auth, Firestore) backend. Built against the SRS
in this repo's project brief: student-facing app only in this pass (no admin panel yet).

## 1. Setup

```bash
npm install
cp .env.example .env.local   # already pre-filled with your Firebase project's web config
npm run dev
```

The web config in `.env.local` is **not a secret** (see `src/app/config/firebase.ts` for why) —
it's fine that it's in a plain file. Nothing that *is* secret (a service-account key, an Admin
SDK credential) ever appears in this app; the one place a secret is used is
`scripts/seed-students.mjs`, which never ships to the browser.

## 2. Firebase project setup (one-time, in the Firebase Console)

1. **Enable Email/Password sign-in**: Authentication → Sign-in method → Email/Password → Enable.
   Roll-number login is built on top of this (see "Auth model" below) — without it, sign-in will
   fail with `auth/operation-not-allowed`.
2. **Create Firestore** in production mode if you haven't already (Firestore Database → Create
   database).
3. **Deploy security rules and indexes** (requires the Firebase CLI, `npm i -g firebase-tools`
   then `firebase login`):
   ```bash
   firebase deploy --only firestore:rules,firestore:indexes
   ```
   The composite indexes in `firestore.indexes.json` are required for the queries in
   `src/services/*` — without them, those reads fail with a Firestore "index required" error
   that includes a direct console link to create it, if you'd rather do it that way.

## 3. Seed demo data

```bash
# Firebase Console → Project Settings → Service Accounts → Generate new private key
# save the download as ./service-account.json (already gitignored)
npm run seed
```

This creates one demo student (roll number `23A31A05B1`, password `Handy@123`, printed again at
the end of the script), 8 subjects, a published timetable version, and attendance summaries that
match the reference mockups exactly, so the app renders real numbers on first login. It also
seeds individual `attendance` records for every held class (evenly distributed present/absent so
the History list and the Attendance calendar view have real per-day data, not just aggregates),
two `leaveRequests` (one approved, one pending), and five `notifications` covering every
notification type. Re-running `npm run seed` is idempotent — records use deterministic ids.

## 4. Sign in

Open the app, enter roll number `23A31A05B1` and password `Handy@123` (or whatever you seeded).

## Auth model: roll number + password

Firebase Authentication has no native "roll number" method — it's email/password under the hood.
`rollNumberToEmail()` in `src/services/firebase/auth.ts` deterministically maps a roll number to a
synthetic address (`23a31a05b1@handy.local` by default; the domain is `VITE_AUTH_EMAIL_DOMAIN`),
then uses Firebase's normal, well-tested email/password flow. Students never see or type this
address. Accounts are provisioned ahead of time by an administrator — `scripts/seed-students.mjs`
today, a real admin panel or Cloud Function later — students only ever sign in, never self-register.
This keeps the roll-number requirement out of Firestore security rules entirely (Firebase Auth
already guarantees uniqueness/hashing/rate-limiting on the email/password pair).

## What's implemented

Everything under student scope from the SRS: roll-number login, home dashboard, subjects list +
detail, attendance history (paginated list **and** a month-grid calendar view colored by daily
status), attendance planner (three tabs: classes needed to reach target, projected attendance if
you attend regularly, and per-subject goal tracking with safe-absence counts), timetable with
version selection by effective date, jump-to-date, and a "Report a Change" form, leave planner
(impact calculator + recommendation + alternative dates), leave request + history, profile
(personal + academic info), notifications, and a tabbed Overall Attendance screen (Overview /
Subjects / Timetable / History) matching the mockups' tab pattern. Every page has loading/empty/error
states — tailored skeletons that mirror each page's real layout, not a single generic placeholder —
and offline is signaled via a banner, never silently pretended to sync.

**Not implemented in this pass** (explicitly out of scope per the brief): the admin panel,
Cloud Functions for timetable publishing/leave approval/notification fan-out, and a live
"Mark Present" write path — `recordAttendance()` exists in the service layer but firestore.rules
deliberately denies students from writing to `attendance`/`attendanceSummaries` directly (SRS
§25, §36), so nothing in the UI currently calls it. Wire it up behind a Cloud Function when you
build that flow.

## Verification note (read this before trusting a green build blindly)

This project was authored in a sandboxed environment whose network policy blocks the npm
registry, so **`npm install`, `npm run build`, `npm run lint`, and `npm run test` (vitest) could
not actually be executed against this exact code** before delivery. What *was* verified here,
with real evidence, not assumptions:

- The entire attendance/leave/timetable calculation engine (`src/lib/calculations/*`) was
  exercised with real assertions via Node's `tsx` runtime (globally available, dependency-free) —
  every formula in SRS §11-16, and the §67-69 worked examples, actually ran and produced the
  claimed output. Two bugs were caught and fixed this way: the required-classes formula for two
  of the reference mockup's subjects doesn't match the mockup's own (apparently unverified)
  numbers — the code follows the textual formula in §13, confirmed correct by direct computation;
  see the comments in `attendance.test.ts` for the specific discrepancy.
- Every `@/...` import across all 83 source files was cross-checked against the target file's
  actual exports, and every relative import (including every `.module.css`) was checked to
  resolve to a real file — zero mismatches found.
- Two real type-correctness bugs in the Firestore write paths (`submitLeaveRequest`,
  `recordAttendance` — both used a converter-typed collection with a data shape missing the
  required `id` field) were found by manual review and fixed.

What was **not** verified: a full TypeScript compile against the real `react-router-dom`,
`firebase`, `zod`, `react-hook-form`, and `@tanstack/react-query` type definitions (they aren't
installed here), so it's possible a narrower type mismatch against one of those libraries' exact
API surface remains. After `npm install`, please run:

```bash
npm run typecheck && npm run lint && npm test && npm run build
```

and send me anything that fails — I'd rather fix a real error against real output than guess.
