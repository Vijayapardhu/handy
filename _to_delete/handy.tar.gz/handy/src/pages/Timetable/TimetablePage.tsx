import { useMemo, useState } from "react";
import { RefreshCcw, CalendarX2 } from "lucide-react";
import { TopHeader } from "@/components/layout/TopHeader";
import { DayTabs } from "@/components/timetable/DayTabs";
import { ClassCard } from "@/components/timetable/ClassCard";
import { Skeleton } from "@/components/ui/Skeleton";
import { ErrorState } from "@/components/ui/ErrorState";
import { EmptyState } from "@/components/ui/EmptyState";
import { useActiveTimetable } from "@/hooks/useTimetable";
import { useActiveSubjectsMap } from "@/hooks/useActiveSubjectsMap";
import { getEntriesForDay } from "@/lib/calculations/timetable";
import { addDaysIso, dayOfWeekFromIso, formatDisplayDate, todayIso } from "@/lib/date";
import styles from "./TimetablePage.module.css";

function weekDates(anchor: string): string[] {
  const anchorDow = dayOfWeekFromIso(anchor);
  // Week starts Monday for display, matching the reference mockup.
  const mondayOffset = anchorDow === 0 ? -6 : 1 - anchorDow;
  const monday = addDaysIso(anchor, mondayOffset);
  return Array.from({ length: 7 }, (_, i) => addDaysIso(monday, i));
}

export function TimetablePage() {
  const today = todayIso();
  const [selectedDate, setSelectedDate] = useState(today);
  const timetableQuery = useActiveTimetable(selectedDate);
  const subjectsMap = useActiveSubjectsMap();

  const dates = useMemo(() => weekDates(selectedDate), [selectedDate]);
  const dayEntries = useMemo(() => {
    if (!timetableQuery.data) return [];
    return getEntriesForDay(timetableQuery.data.entries, dayOfWeekFromIso(selectedDate));
  }, [timetableQuery.data, selectedDate]);

  return (
    <div>
      <TopHeader title="Timetable" subtitle="Your class schedule at a glance" />

      {timetableQuery.data?.version && (
        <div className={styles.versionBanner}>
          <span>
            Version {timetableQuery.data.version.versionNumber} · Active
          </span>
          <span className={styles.versionRange}>
            {formatDisplayDate(timetableQuery.data.version.effectiveFrom)}
            {timetableQuery.data.version.effectiveUntil
              ? ` – ${formatDisplayDate(timetableQuery.data.version.effectiveUntil)}`
              : " onward"}
          </span>
        </div>
      )}

      <DayTabs dates={dates} selected={selectedDate} onSelect={setSelectedDate} todayIso={today} />

      {timetableQuery.isError && (
        <ErrorState
          message="Unable to load your timetable. Please check your connection and try again."
          onRetry={() => timetableQuery.refetch()}
        />
      )}

      {!timetableQuery.isError && timetableQuery.isLoading && (
        <div className={styles.loadingStack}>
          <Skeleton height={70} />
          <Skeleton height={70} />
          <Skeleton height={70} />
        </div>
      )}

      {!timetableQuery.isError && !timetableQuery.isLoading && !timetableQuery.data?.version && (
        <EmptyState
          icon={CalendarX2}
          title="No timetable available"
          description="Your timetable has not been published yet."
        />
      )}

      {!timetableQuery.isError &&
        !timetableQuery.isLoading &&
        timetableQuery.data?.version &&
        dayEntries.length === 0 && (
          <EmptyState title="No classes today" description="Enjoy the day off!" />
        )}

      {!timetableQuery.isError &&
        !timetableQuery.isLoading &&
        dayEntries.map((entry) => (
          <ClassCard key={entry.id} entry={entry} subject={subjectsMap.bySubjectId.get(entry.subjectId)} />
        ))}

      <div className={styles.updateBanner}>
        <RefreshCcw size={16} />
        <div className={styles.updateBannerText}>
          <p className={styles.updateBannerTitle}>Timetable can change frequently</p>
          <p className={styles.updateBannerSubtitle}>
            {timetableQuery.data?.version?.publishedAt
              ? `Last published ${formatDisplayDate(timetableQuery.data.version.publishedAt.slice(0, 10))}`
              : "Check back for updates"}
          </p>
        </div>
        <button className={styles.checkButton} onClick={() => timetableQuery.refetch()}>
          Check for Updates
        </button>
      </div>
    </div>
  );
}
